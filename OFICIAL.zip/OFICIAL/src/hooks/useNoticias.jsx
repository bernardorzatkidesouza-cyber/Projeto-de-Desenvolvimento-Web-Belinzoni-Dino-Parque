import { useState, useEffect, useCallback } from "react";
import { pegar, enviar } from "../services/api";

function useNoticias() {
  const [noticias, setNoticias] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState(null);

  const buscarNoticias = useCallback(async () => {
    try {
      setCarregando(true);
      setErro(null);
      setNoticias(await pegar("/api/noticias"));
    } catch (e) {
      setErro(e.message);
      console.error("Erro ao buscar notícias:", e);
    } finally {
      setCarregando(false);
    }
  }, []);

  async function cadastrarNoticia(dados) {
    await enviar("/api/noticias", "POST", dados);
    await buscarNoticias();
  }

  async function atualizarNoticia(id, dados) {
    await enviar(`/api/noticias/${id}`, "PUT", dados);
    await buscarNoticias();
  }

  async function removerNoticia(id) {
    await enviar(`/api/noticias/${id}`, "DELETE");
    await buscarNoticias();
  }

  useEffect(() => { buscarNoticias(); }, [buscarNoticias]);

  return { noticias, carregando, erro, buscarNoticias, cadastrarNoticia, atualizarNoticia, removerNoticia };
}

export default useNoticias;
