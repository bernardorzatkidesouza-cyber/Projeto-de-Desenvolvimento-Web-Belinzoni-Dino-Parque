
import { useState, useEffect, useCallback } from "react";

const API_URL = "/api/perguntas_frequentes";

function useDuvidas() {
  const [duvidas, setDuvidas] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState("");

  // BUSCAR DÚVIDAS
  const buscarDuvidas = useCallback(async () => {
    try {
      setCarregando(true);
      setErro("");

      const resposta = await fetch(API_URL);

      if (!resposta.ok) {
        throw new Error("Não foi possível buscar as dúvidas.");
      }

      const dados = await resposta.json();

      setDuvidas(
        Array.isArray(dados) ? dados : dados.content || []
      );
    } catch (erro) {
      setErro(erro.message);
    } finally {
      setCarregando(false);
    }
  }, []);

  useEffect(() => {
    buscarDuvidas();
  }, [buscarDuvidas]);

  // CADASTRAR DÚVIDA
   body: JSON.stringify({
  pergunta: duvida.pergunta,
  resposta: duvida.resposta,
  categoria: duvida.categoria || "geral",
  ordem_exibicao: Number(duvida.ordem_exibicao) || 0,
}),

  // EXCLUIR DÚVIDA
  async function excluirDuvida(id) {
    const resposta = await fetch(`${API_URL}/${id}`, {
      method: "DELETE",
    });

    if (!resposta.ok) {
      throw new Error("Erro ao excluir a dúvida.");
    }

    await buscarDuvidas();
  }

  return {
    duvidas,
    carregando,
    erro,
    buscarDuvidas,
    adicionarDuvida,
    atualizarDuvida,
    excluirDuvida,
  };
}

export default useDuvidas;
