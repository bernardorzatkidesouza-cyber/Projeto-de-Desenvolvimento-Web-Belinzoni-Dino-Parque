export const API = "/api";

// Busca pública (sem login)
export async function pegar(caminho) {
  const r = await fetch(caminho);
  if (!r.ok) throw new Error(`Falha ao carregar (HTTP ${r.status})`);
  return r.json();
}

// Envio autenticado (usa o token do login)
export async function enviar(caminho, metodo, corpo) {
  const token = localStorage.getItem("token");
  const r = await fetch(caminho, {
    method: metodo,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: corpo ? JSON.stringify(corpo) : undefined,
  });
  if (r.status === 204) return null;
  const dados = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(dados.erro || `Falha na operação (HTTP ${r.status})`);
  return dados;
}

// Upload de imagem (multipart)
export async function enviarImagem(arquivo) {
  const token = localStorage.getItem("token");
  const fd = new FormData();
  fd.append("imagem", arquivo);
  const r = await fetch("/api/upload", {
    method: "POST",
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: fd,
  });
  const dados = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(dados.erro || "Falha no envio da imagem");
  return dados.url;
}
